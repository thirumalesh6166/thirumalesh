import streamlit as st
import pandas as pd
import joblib

# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="AI Heart Disease Prediction",
    page_icon="❤️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown("""
<style>

.main {
    background-color: #0e1117;
}

.block-container {
    padding-top: 2rem;
    padding-bottom: 3rem;
}

.hero {
    padding: 30px;
    border-radius: 18px;
    background: linear-gradient(
        135deg,
        #151a25,
        #20283a
    );
    border: 1px solid #303849;
    margin-bottom: 25px;
}

.hero h1 {
    font-size: 42px;
    margin-bottom: 8px;
}

.hero p {
    font-size: 18px;
    color: #b8c0cc;
}

.section-title {
    font-size: 28px;
    font-weight: 700;
    margin-top: 25px;
    margin-bottom: 15px;
}

.info-card {
    padding: 20px;
    border-radius: 15px;
    background: #171c27;
    border: 1px solid #303849;
}

.footer {
    text-align: center;
    color: #7f8794;
    padding: 30px;
    margin-top: 40px;
}

</style>
""", unsafe_allow_html=True)

# ============================================================
# LOAD MODEL
# ============================================================

@st.cache_resource
def load_model():
    return joblib.load("final_health_prediction_model.pkl")


model = load_model()

# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:

    st.title("❤️ Health AI")

    st.markdown("---")

    st.markdown("""
    ### Navigation

    🏠 **Prediction**

    📊 **Model Performance**

    🧠 **Model Comparison**

    📚 **Project Information**
    """)

    st.markdown("---")

    st.info(
        "This application is an educational machine-learning "
        "project. It is not a medical diagnostic system."
    )

# ============================================================
# HERO SECTION
# ============================================================

st.markdown("""
<div class="hero">

<h1>❤️ AI Heart Disease Prediction</h1>

<p>
A machine-learning based educational system that analyzes
general health, medical and lifestyle information.
</p>

</div>
""", unsafe_allow_html=True)

# ============================================================
# TOP METRICS
# ============================================================

m1, m2, m3, m4 = st.columns(4)

with m1:
    st.metric(
        "Model Accuracy",
        "73.83%"
    )

with m2:
    st.metric(
        "Recall",
        "80.10%"
    )

with m3:
    st.metric(
        "ROC-AUC",
        "83.92%"
    )

with m4:
    st.metric(
        "Model",
        "Logistic Regression"
    )

st.divider()

# ============================================================
# PREDICTION SECTION
# ============================================================

st.markdown(
    '<div class="section-title">👤 Personal Information</div>',
    unsafe_allow_html=True
)

col1, col2, col3 = st.columns(3)

with col1:

    sex = st.selectbox(
        "Sex",
        ["Female", "Male"]
    )

with col2:

    age_category = st.selectbox(
        "Age Category",
        [
            "18-24",
            "25-29",
            "30-34",
            "35-39",
            "40-44",
            "45-49",
            "50-54",
            "55-59",
            "60-64",
            "65-69",
            "70-74",
            "75-79",
            "80+"
        ]
    )

with col3:

    height = st.number_input(
        "Height (cm)",
        min_value=91.0,
        max_value=241.0,
        value=170.0,
        step=0.1
    )

col1, col2, col3 = st.columns(3)

with col1:

    weight = st.number_input(
        "Weight (kg)",
        min_value=24.95,
        max_value=293.02,
        value=70.0,
        step=0.1
    )

with col2:

    bmi = st.number_input(
        "BMI",
        min_value=12.02,
        max_value=99.33,
        value=24.0,
        step=0.01
    )

with col3:

    general_health = st.selectbox(
        "General Health",
        [
            "Excellent",
            "Very Good",
            "Good",
            "Fair",
            "Poor"
        ]
    )

# ============================================================
# HEALTH INFORMATION
# ============================================================

st.markdown(
    '<div class="section-title">🏥 Health Information</div>',
    unsafe_allow_html=True
)

col1, col2, col3 = st.columns(3)

with col1:

    checkup = st.selectbox(
        "Last Checkup",
        [
            "Within the past year",
            "Within the past 2 years",
            "Within the past 5 years",
            "5 or more years ago",
            "Never"
        ]
    )

with col2:

    exercise = st.selectbox(
        "Exercise",
        ["Yes", "No"]
    )

with col3:

    smoking = st.selectbox(
        "Smoking History",
        ["Yes", "No"]
    )

col1, col2, col3 = st.columns(3)

with col1:

    skin_cancer = st.selectbox(
        "Skin Cancer",
        ["Yes", "No"]
    )

with col2:

    other_cancer = st.selectbox(
        "Other Cancer",
        ["Yes", "No"]
    )

with col3:

    depression = st.selectbox(
        "Depression",
        ["Yes", "No"]
    )

col1, col2 = st.columns(2)

with col1:

    diabetes = st.selectbox(
        "Diabetes",
        [
            "No",
            "Yes",
            "No, borderline diabetes",
            "Yes, during pregnancy"
        ]
    )

with col2:

    arthritis = st.selectbox(
        "Arthritis",
        ["Yes", "No"]
    )

# ============================================================
# LIFESTYLE
# ============================================================

st.markdown(
    '<div class="section-title">🥗 Lifestyle Information</div>',
    unsafe_allow_html=True
)

col1, col2, col3, col4 = st.columns(4)

with col1:

    alcohol = st.number_input(
        "Alcohol Consumption",
        min_value=0,
        max_value=30,
        value=0
    )

with col2:

    fruit = st.number_input(
        "Fruit Consumption",
        min_value=0,
        max_value=120,
        value=30
    )

with col3:

    vegetables = st.number_input(
        "Green Vegetables",
        min_value=0,
        max_value=128,
        value=12
    )

with col4:

    fried_potato = st.number_input(
        "Fried Potato Consumption",
        min_value=0,
        max_value=128,
        value=4
    )

# ============================================================
# PREDICTION BUTTON
# ============================================================

st.divider()

predict_button = st.button(
    "🔍  PREDICT HEART DISEASE RISK",
    use_container_width=True,
    type="primary"
)

# ============================================================
# PREDICTION
# ============================================================

if predict_button:

    input_data = pd.DataFrame({

        "General_Health": [general_health],

        "Checkup": [checkup],

        "Exercise": [exercise],

        "Skin_Cancer": [skin_cancer],

        "Other_Cancer": [other_cancer],

        "Depression": [depression],

        "Diabetes": [diabetes],

        "Arthritis": [arthritis],

        "Sex": [sex],

        "Age_Category": [age_category],

        "Height_(cm)": [height],

        "Weight_(kg)": [weight],

        "BMI": [bmi],

        "Smoking_History": [smoking],

        "Alcohol_Consumption": [alcohol],

        "Fruit_Consumption": [fruit],

        "Green_Vegetables_Consumption": [vegetables],

        "FriedPotato_Consumption": [fried_potato]
    })

    # Prediction

    prediction = model.predict(input_data)[0]

    probability = model.predict_proba(input_data)[0]

    positive_probability = probability[1] * 100

    negative_probability = probability[0] * 100

    # ========================================================
    # RESULT
    # ========================================================

    st.divider()

    st.markdown(
        '<div class="section-title">📊 Prediction Result</div>',
        unsafe_allow_html=True
    )

    if prediction == 1:

        st.error(
            "⚠️ Model Prediction: Heart Disease = YES"
        )

    else:

        st.success(
            "✅ Model Prediction: Heart Disease = NO"
        )

    r1, r2, r3 = st.columns(3)

    with r1:

        st.metric(
            "Heart Disease Probability",
            f"{positive_probability:.2f}%"
        )

    with r2:

        st.metric(
            "No Heart Disease Probability",
            f"{negative_probability:.2f}%"
        )

    with r3:

        st.metric(
            "Prediction",
            "YES" if prediction == 1 else "NO"
        )

    st.progress(
        int(min(max(positive_probability, 0), 100))
    )

    st.caption(
        "The probability shown is the model's predicted probability "
        "for the positive class in this dataset. It is not a clinical "
        "risk score or medical diagnosis."
    )

    st.warning(
        "⚠️ Educational project only. This prediction should not be "
        "used to diagnose, treat, or rule out heart disease. Consult "
        "a qualified healthcare professional for medical advice."
    )

# ============================================================
# MODEL PERFORMANCE
# ============================================================

st.divider()

st.markdown(
    '<div class="section-title">📈 Model Performance Dashboard</div>',
    unsafe_allow_html=True
)

performance_data = pd.DataFrame({

    "Metric": [
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score",
        "ROC-AUC"
    ],

    "Logistic Regression": [
        73.83,
        20.86,
        80.10,
        33.10,
        83.92
    ],

    "Linear SVM": [
        73.41,
        20.70,
        80.86,
        32.96,
        83.91
    ]
})

st.dataframe(
    performance_data,
    use_container_width=True,
    hide_index=True
)

st.subheader("📊 Model Metrics Comparison")

chart_data = performance_data.set_index("Metric")

st.bar_chart(chart_data)

# ============================================================
# MODEL COMPARISON
# ============================================================

st.divider()

st.markdown(
    '<div class="section-title">🧠 Logistic Regression vs Linear SVM</div>',
    unsafe_allow_html=True
)

comparison_col1, comparison_col2 = st.columns(2)

with comparison_col1:

    st.markdown("### Logistic Regression")

    st.metric(
        "Accuracy",
        "73.83%"
    )

    st.metric(
        "Precision",
        "20.86%"
    )

    st.metric(
        "Recall",
        "80.10%"
    )

    st.metric(
        "F1 Score",
        "33.10%"
    )

    st.metric(
        "ROC-AUC",
        "83.92%"
    )

with comparison_col2:

    st.markdown("### Linear SVM")

    st.metric(
        "Accuracy",
        "73.41%"
    )

    st.metric(
        "Precision",
        "20.70%"
    )

    st.metric(
        "Recall",
        "80.86%"
    )

    st.metric(
        "F1 Score",
        "32.96%"
    )

    st.metric(
        "ROC-AUC",
        "83.91%"
    )

# ============================================================
# CONFUSION MATRICES
# ============================================================

st.divider()

st.markdown(
    '<div class="section-title">🧩 Confusion Matrices</div>',
    unsafe_allow_html=True
)

cm1, cm2 = st.columns(2)

with cm1:

    st.subheader("Logistic Regression")

    logistic_cm = pd.DataFrame(
        [
            [41605, 15172],
            [994, 4000]
        ],
        columns=[
            "Predicted No",
            "Predicted Yes"
        ],
        index=[
            "Actual No",
            "Actual Yes"
        ]
    )

    st.dataframe(
        logistic_cm,
        use_container_width=True
    )

with cm2:

    st.subheader("Linear SVM")

    svm_cm = pd.DataFrame(
        [
            [41307, 15470],
            [956, 4038]
        ],
        columns=[
            "Predicted No",
            "Predicted Yes"
        ],
        index=[
            "Actual No",
            "Actual Yes"
        ]
    )

    st.dataframe(
        svm_cm,
        use_container_width=True
    )

# ============================================================
# DATASET INFORMATION
# ============================================================

st.divider()

st.markdown(
    '<div class="section-title">📚 Dataset & Project Information</div>',
    unsafe_allow_html=True
)

info1, info2, info3 = st.columns(3)

with info1:

    st.markdown("""
    ### Dataset

    **CVD Cleaned Dataset**

    • 308,854 records  
    • 19 columns  
    • 18 input features  
    • 1 target variable
    """)

with info2:

    st.markdown("""
    ### Machine Learning

    **Primary Model**

    Logistic Regression

    **Comparison Model**

    Linear SVM

    **Preprocessing**

    StandardScaler + OneHotEncoder
    """)

with info3:

    st.markdown("""
    ### Target

    **Heart Disease**

    No → 0

    Yes → 1

    The dataset contains a substantially larger
    number of No cases than Yes cases.
    """)

# ============================================================
# PROJECT WORKFLOW
# ============================================================

st.divider()

st.markdown(
    '<div class="section-title">⚙️ Machine Learning Workflow</div>',
    unsafe_allow_html=True
)

workflow = pd.DataFrame({
    "Step": [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6"
    ],

    "Process": [
        "Data Collection",
        "Data Preprocessing",
        "Train/Test Split",
        "Model Training",
        "Model Evaluation",
        "Prediction"
    ],

    "Description": [
        "CVD health dataset",
        "Encoding and feature scaling",
        "80% training / 20% testing",
        "Logistic Regression and Linear SVM",
        "Accuracy, Precision, Recall, F1 and ROC-AUC",
        "Prediction using trained pipeline"
    ]
})

st.dataframe(
    workflow,
    use_container_width=True,
    hide_index=True
)

# ============================================================
# FOOTER
# ============================================================

st.markdown("""
<div class="footer">

### ❤️ AI Heart Disease Prediction System

Machine Learning Project | CVD Cleaned Dataset

Educational and research demonstration only.

</div>
""", unsafe_allow_html=True)